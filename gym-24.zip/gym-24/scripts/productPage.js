document.addEventListener("DOMContentLoaded", () => {
    const param = location.search.split("=")[1];

    const mainImg = document.querySelector("#main-img");

    const products = {
        "123": {
          name: "Exercise Ball",
          price: "$20.99",
          description: "A versatile exercise tool for improving core strength and stability.",
          features: ["Durable PVC material", "Available in various sizes", "Anti-burst design for safety"],
          imgs: [
            "https://m.media-amazon.com/images/I/51T5RPDAS1L._AC_UF1000,1000_QL80_.jpg",
            "https://www.solara.in/cdn/shop/products/BAL_Main_Blue.png?v=1692163665&width=1946",
            "https://www.shape.com/thmb/FMrfN7urnQTneWjojIpFCGyTYls=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/best-exercise-balls-tout-891f8e57165641c785a19c8a24fa1c5e.jpg",
            "https://mensfitnesstoday.com/wp-content/uploads/sites/2/2022/07/gym-ball-cossack-squat-2.jpg"
          ]
        },
        "345":{
          name: "Resistance Bands",
          price: "$15.49",
          description: "Elastic bands for effective strength training and muscle toning.",
          features: ["Different resistance levels", "Compact and portable", "Ideal for home workouts"],
          imgs:[
            "https://m.media-amazon.com/images/I/71+hji+OIlL._AC_UF894,1000_QL80_.jpg",
            "https://hips.hearstapps.com/hmg-prod/images/woman-using-resistance-band-at-home-in-living-room-royalty-free-image-1679940066.jpg",
            "https://m.media-amazon.com/images/I/819fNejp7eL._AC_UF894,1000_QL80_.jpg",
            "https://static.nike.com/a/images/f_auto,cs_srgb/w_1536,c_limit/6a2e66f2-6351-4c92-ab5b-b06470aa8f95/the-best-resistance-band-exercises-for-beginners.jpg",
          ]
        },
        "567": {
          name: "Gripper",
          price: "$9.99",
          description: "Hand gripper for enhancing grip strength and forearm muscles.",
          features: ["Adjustable resistance levels", "Comfortable ergonomic grip", "Durable construction"],
          imgs:[
            "https://images.naptol.com/usr/local/csp/staticContent/product_images/horizontal/750x750/AdjustableHandGripper---1.jpg",
            "https://www.cockatooindia.com/cdn/shop/files/71hBaqt6xlL._SL1500.jpg?v=1687000421",
            "https://www.solara.in/cdn/shop/products/image_1_6e27f28d-72ac-4b2d-84e6-c96db1f04b60.png?v=1641545983&width=1946",
            "https://rukminim2.flixcart.com/image/850/1000/kjbr8280-0/fitness-grip/o/h/4/hand-gripper-for-best-hand-exerciser-grip-adjustable-10kg-original-imaf7jp6bednncnz.jpeg?q=90"
          ]
        },
        "789":{
          name: "Skipping Rope",
          price: "$12.79",
          description: "A classic cardio tool for improving endurance and agility.",
          features: ["Adjustable length", "Non-slip handles", "Suitable for all fitness levels"],
          imgs:[
            "https://m.media-amazon.com/images/I/61VqnE79V2L.jpg",
            "https://rukminim2.flixcart.com/image/850/1000/kmkxbww0/skipping-rope/y/q/v/plastic-and-rubber-skipping-rope-with-jump-counter-na-spocco-original-imagfghvjsnk3j77.jpeg?q=20",
            "https://m.media-amazon.com/images/I/61J65Fm47HL._AC_UF894,1000_QL80_.jpg",
            "https://m.media-amazon.com/images/I/71V7BaHBcqL._AC_UF894,1000_QL80_.jpg"
          ]
        },
        "901":{
          name: "Yoga Mat",
          price: "$24.99",
          description: "Non-slip mat for yoga, Pilates, and other floor exercises.",
          features: ["Extra thick for comfort", "High-density foam material", "Easy to clean and store"],
          imgs:[
            "https://www.jiomart.com/images/product/original/rvpcuiugex/octus-exercise-yoga-mat-6mm-pack-of-1-product-images-orvpcuiugex-p591174211-0-202203010402.jpg?im=Resize=(1000,1000)",
            "https://images-static.nykaa.com/media/catalog/product/c/c/cc270b1YS-TPE-YM601-P&B_1.jpg",
            "https://assetscdn1.paytm.com/images/catalog/product/S/SP/SPOSTRAUSS-NBR-KHEL193268E2FF5019/1612004222297_17.jpg",
            "https://www.sdsportshub.com/wp-content/uploads/2020/06/Colours-of-Yoga-Mat.jpg"
          ]
        },
        "234":{
          name: "Treadmill",
          price: "$599.99",
          description: "Motorized treadmill for indoor cardiovascular workouts.",
          features: ["Multiple speed settings", "Incline options for varied intensity", "Built-in heart rate monitor"],
          imgs:[
            "https://m.media-amazon.com/images/I/61jTo5c6NTL.jpg",
           "https://reach2fitness.com/cdn/shop/products/518iBizdd9L_0a2701d5-8eb6-4e89-b8d4-40a35ac34fae.jpg?v=1690498295" ,
           "https://img.beatxp.com/prod/product/249/2%20%2814%29.webp",
           "https://static.nike.com/a/images/f_auto,cs_srgb/w_1536,c_limit/67916f7c-35d6-48a9-9084-1b31e1218a2c/the-5-benefits-of-running-on-a-treadmill-according-to-experts.jpg"
          ]
        },
        "456":{
          name: "Elliptical Trainer",
          price: "$799.00",
          description: "Low-impact elliptical machine for full-body workouts.",
          features: ["Smooth and natural motion", "Adjustable resistance levels", "LCD display for tracking progress"],
          imgs: [
            "https://images-cdn.ubuy.co.in/63bcbbe568135974502b0d13-niceday-elliptical-machine-cross.jpg",
            "https://images.jdmagicbox.com/quickquotes/images_main/e95_142409907281285800.JPG",
            "https://m.media-amazon.com/images/I/813d6dC6KuL._AC_UF894,1000_QL80_.jpg",
            "https://img.beatxp.com/prod/product/269/Untitled-4%20copy%20%2820%29.webp"
          ]
        }
    };

    mainImg.src = products[param].imgs[0]

    const handleClick = (index) => {
        mainImg.src = products[param].imgs[index]
    }

    const images =Array.from(document.querySelector(".prod-imgs").children);

    images.map((el, i) => {
        el.src = products[param].imgs[i];

        el.addEventListener("click", () => {
            handleClick(i)
        })
    })

    const keys = Object.keys(products).filter(e=>  e!= param);

    const recommendationContainer = document.querySelector(".recommendation>.cards");

    let recommendedProds = ``;

    keys.map((el) => {
        recommendedProds += `
        <div class="card" onclick = "window.location.href='../pages/product.html?id=${el}'">
        <img src=${products[el].imgs[0]} alt="">
        <p>${products[el].name}</p>
      </div>
        `
    })

    recommendationContainer.innerHTML = recommendedProds;

    const productHeading = document.querySelector(".product-description>span>h1")
    productHeading.textContent = products[param].name;

    const productId = document.querySelector(".product-description>span>p.light");
    productId.textContent = `Product id: #${param}`

    const productDescription = document.querySelector(".product-description>p.desc")
    productDescription.textContent = products[param].description

    const productFeatures = document.querySelector(".product-description>span>#product-features")
    let features = "";

    products[param].features.map((e) => {
        features +=  `<li>${e}</li>`
     })
    productFeatures.innerHTML = features;

    const productPrice = document.querySelector(".product-description>.price-tag");
    productPrice.textContent = `${products[param].price}`
})